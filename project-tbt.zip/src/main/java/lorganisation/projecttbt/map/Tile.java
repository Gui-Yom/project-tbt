package lorganisation.projecttbt.map;

public interface Tile {

    boolean canStepOn();

    String getIcon();
}
